public class InvalidNodeException extends Exception {
    public InvalidNodeException(String m){
        super(m);
    }
}
